# TerraFusion Alpha DevKit (Core Edition)

## Included Modules

- Field_PWA/ → Mobile-first field toolkit (offline-ready)
- Event_Timeline_UI/ → Timeline SHAP + audit replay
- Cognitive_Intelligence/
    - voice_to_narrative.json → Speech-to-narrative engine
    - scorecam_snapshot.json → Condition scoring CV snapshot
    - smart_ledger_v2.json → Decision log with SHAP overrides
    - event_timeline.json → Interactive audit trail

## Deploy Recommendations

- Use Vercel or Firebase for frontends
- Backend: FastAPI or Node for ledger + SHAP services
- Use this as the pilot install base for field testing and internal demos

This is TerraFusion. A cognitive valuation co-agent, built for truth.