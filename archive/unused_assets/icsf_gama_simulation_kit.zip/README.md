# ICSF-Compatible GAMA Simulation Framework

This simulation package supports geo-assisted mass appraisal (GAMA) with:
- Spatial feature engineering (entropy, viewshed, POI distance)
- Policy simulation
- Valuation modeling (Random Forest)
- Compliance audit logging
- GeoJSON and CSV outputs for visualization

## Structure

```
.
├── data/
├── output/
├── logs/
├── model/
├── icsf_gama_simulation.py
├── requirements.txt
├── run.sh
├── .replit
├── replit.nix
└── README.md
```

## Instructions

```bash
pip install -r requirements.txt
python icsf_gama_simulation.py
```

Outputs saved to `output/`. Logging available under `logs/`.

## DevOps & Execution
- Use `run.sh` for batch execution
- Log file: `logs/compliance_audit.log`

## Licensing
For educational and simulation use only, under the ICSF framework.
