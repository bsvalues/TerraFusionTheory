#!/bin/bash
mkdir -p output logs
python3 icsf_gama_simulation.py
