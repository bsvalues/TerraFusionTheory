import React, { useEffect, useState } from 'react';
import Plot from 'react-plotly.js';
import './styles/terrafusion-theme.css';

export default function CompImpactVisualizer({ shapData }) {
  const [data, setData] = useState([]);

  useEffect(() => {
    if (shapData) {
      const sorted = [...shapData].sort((a, b) => Math.abs(b.impact) - Math.abs(a.impact));
      const features = sorted.map(s => s.feature);
      const impacts = sorted.map(s => s.impact);
      const colors = impacts.map(val => val > 0 ? '#00e6d2' : '#ff5c5c');

      setData([{
        type: 'bar',
        x: impacts,
        y: features,
        orientation: 'h',
        marker: { color: colors },
        text: impacts.map(i => `$${Math.round(i).toLocaleString()}`),
        textposition: 'auto',
      }]);
    }
  }, [shapData]);

  if (!shapData) return null;

  return (
    <div className="card" style={{ marginTop: '1rem' }}>
      <h4 style={{ marginBottom: '0.5rem' }}>Comp SHAP Impact</h4>
      <Plot
        data={data}
        layout={{
          width: 480,
          height: 300,
          margin: { l: 80, r: 20, t: 30, b: 30 },
          paper_bgcolor: 'var(--tf-surface)',
          plot_bgcolor: 'var(--tf-surface)',
          font: { color: 'var(--tf-text)' },
          xaxis: { title: 'Valuation Impact ($)', zeroline: false }
        }}
      />
    </div>
  );
}