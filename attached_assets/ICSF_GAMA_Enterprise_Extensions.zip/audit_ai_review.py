import re

def analyze_log(file_path):
    with open(file_path) as f:
        lines = f.readlines()

    findings = []
    for line in lines:
        if "ERROR" in line or "FAILED" in line:
            findings.append(("High", line.strip()))
        elif "warning" in line.lower():
            findings.append(("Medium", line.strip()))
        elif "success" in line.lower():
            findings.append(("Info", line.strip()))

    for level, message in findings:
        print(f"[{level}] {message}")

if __name__ == "__main__":
    analyze_log("logs/compliance_audit.log")