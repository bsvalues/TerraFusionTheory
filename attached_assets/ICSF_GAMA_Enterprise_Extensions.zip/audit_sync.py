import os
import shutil
import datetime

REMOTE_DIR = r"\\sharedserver\icsf_logs"
LOCAL_LOG_DIR = "logs"

def sync_logs():
    if not os.path.exists(LOCAL_LOG_DIR):
        print("No local logs to sync.")
        return

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    dest_dir = os.path.join(REMOTE_DIR, f"logs_{timestamp}")
    os.makedirs(dest_dir, exist_ok=True)

    for log_file in os.listdir(LOCAL_LOG_DIR):
        full_src = os.path.join(LOCAL_LOG_DIR, log_file)
        full_dst = os.path.join(dest_dir, log_file)
        shutil.copy2(full_src, full_dst)
        print(f"Copied {log_file} to {dest_dir}")

if __name__ == "__main__":
    sync_logs()