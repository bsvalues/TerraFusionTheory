import json
import os
import urllib.request
import hashlib
import shutil

UPDATE_MANIFEST_URL = "file:///path/to/internal/update.json"
LOCAL_EXECUTABLE = "ICSF_GAMA_Launcher.exe"
VERSION_FILE = "current_version.txt"

def get_local_version():
    return open(VERSION_FILE).read().strip() if os.path.exists(VERSION_FILE) else "0.0.0"

def fetch_remote_manifest():
    with urllib.request.urlopen(UPDATE_MANIFEST_URL) as response:
        return json.loads(response.read().decode())

def download_update(url, target_file):
    urllib.request.urlretrieve(url, target_file)

def apply_update(manifest):
    print("Applying update...")
    download_update(manifest["download_url"], LOCAL_EXECUTABLE)
    with open(VERSION_FILE, "w") as f:
        f.write(manifest["version"])
    print("Update applied.")

def main():
    local_version = get_local_version()
    manifest = fetch_remote_manifest()
    if manifest["version"] != local_version:
        print(f"New version available: {manifest['version']}")
        apply_update(manifest)
    else:
        print("ICSF GAMA is up to date.")

if __name__ == "__main__":
    main()