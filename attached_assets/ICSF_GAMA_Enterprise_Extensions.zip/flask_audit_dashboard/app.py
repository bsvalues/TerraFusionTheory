from flask import Flask, render_template_string
import os

app = Flask(__name__)
LOG_DIR = "logs"

@app.route("/")
def dashboard():
    logs = []
    for fname in os.listdir(LOG_DIR):
        with open(os.path.join(LOG_DIR, fname)) as f:
            logs.append((fname, f.read()))
    return render_template_string("""
    <h1>ICSF GAMA Audit Dashboard</h1>
    {% for fname, content in logs %}
    <h2>{{ fname }}</h2>
    <pre>{{ content }}</pre>
    {% endfor %}
    """, logs=logs)

if __name__ == "__main__":
    app.run(debug=True, port=5050)