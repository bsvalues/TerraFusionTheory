# ICSF GAMA Simulator (Offline Windows Kit)

## Overview

This package is designed for county IT deployment without internet access. It includes:
- The CLI launcher (no tkinter required)
- Instructions to build a `.exe` locally using PyInstaller
- Sample directory structure and log/output folders

## How to Build the Windows Executable

1. Ensure Python 3.x is installed on the target machine.
2. Open Command Prompt and install PyInstaller:

```
pip install pyinstaller
```

3. From the directory containing `icsf_gui_launcher.py`, run:

```
pyinstaller --onefile --name ICSF_GAMA_Launcher icsf_gui_launcher.py
```

4. The final `.exe` will appear in the `dist` folder. You can place it on the desktop or package it with an installer.

## Folder Structure

```
ICSF_GAMA_Windows_Offline/
├── icsf_gui_launcher.py
├── output/
├── logs/
├── README.txt
```

## Support

This package is intended for internal use by IT departments under the ICSF simulation framework.