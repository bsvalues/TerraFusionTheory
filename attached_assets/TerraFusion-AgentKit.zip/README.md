
# TerraFusion Theory - GAMA Agent Platform

## Overview
TerraFusion Theory is an advanced multi-agent geospatial coordination system integrating intelligent appraisal (GAMA), real-time drift protection (DriftGuard), simulation agents, and policy testing environments.

## Components
- `driftguard_operator.py`: Kubernetes operator detecting and remediating config drift.
- `icsf_gama_simulation.py`: Core GAMA valuation simulation engine.
- `cli_launcher.py`: Windows-compatible CLI launcher.
- `driftguard-anomaly-listener.py`: Kafka consumer that reacts to drift.
- `agent_roles.yaml`: Definition of intelligent agent types.
- `TerraFusionInstaller.exe`: Local deployment installer (mock placeholder here).

## Installation (Local)
Run the `TerraFusionInstaller.exe` to deploy the system locally.

## Replit AI Agent
Use `.replit-agent.json` for contextual intelligence and guidance while coding or deploying.

## Authors
PM, GIS and AI team @ TerraFusion Theory
