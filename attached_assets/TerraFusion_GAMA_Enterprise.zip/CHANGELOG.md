# Changelog

## v1.0.0
- Initial Windows deployment release
- CLI launcher and offline simulation engine
- GeoJSON output and browser visualization
- Compliance logging and PDF report generation

