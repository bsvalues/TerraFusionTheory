# TerraFusion GAMA Simulator (Enterprise Edition)

## Overview
This package provides a fully offline-capable, Windows-compatible mass appraisal simulation platform tailored for local government deployment.

## How to Use
1. Run `TerraFusion_GAMA_Launcher.exe` to start the application.
2. Select from the menu to run simulations, visualize maps, or generate reports.
3. All outputs are stored in the `data/output` and `logs` directories.

## Requirements
- Windows 10 or 11
- No internet connection required

## Support
For technical support, contact your system administrator or the TerraFusion platform integrator.

