// Mock CompAgent SHAP engine
export function getSHAPImpact(compData) {
  // Simulate SHAP deltas based on common patterns
  const shapMap = [
    { feature: "GLA (sqft)", impact: (compData.sqft - 1800) * 10 },
    { feature: "Lot Size", impact: (compData.lot || 0.25 - 0.2) * 2500 },
    { feature: "Condition (C3)", impact: compData.condition === 'C2' ? 2500 : -1500 },
    { feature: "Year Built", impact: (compData.year || 2005) - 2000 > 0 ? 1000 : -800 },
    { feature: "Distance", impact: compData.distance > 1 ? -2000 : 500 }
  ];
  return shapMap;
}