export function generateNarrative(shapData, compIndex) {
  const parts = shapData
    .filter(d => Math.abs(d.impact) > 500)
    .map(d => {
      const val = Math.round(d.impact);
      return `${val > 0 ? '+' : ''}$${Math.abs(val).toLocaleString()} from ${d.feature}`;
    });
  const netImpact = shapData.reduce((acc, cur) => acc + cur.impact, 0);
  const summary = parts.length > 0
    ? `Comp ${compIndex + 1} changed value by ${netImpact > 0 ? '+' : ''}$${Math.round(netImpact).toLocaleString()}: ` + parts.join(', ') + '.'
    : `Comp ${compIndex + 1} had minimal impact.`;
  return summary;
}