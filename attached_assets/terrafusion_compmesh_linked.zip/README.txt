// In CompGridDropzone.jsx inside handleDrop
import { getSHAPImpact } from './CompAgentSHAP';
import { generateNarrative } from './NarrativeAgent';

const shapResult = getSHAPImpact(compData);
const narrative = generateNarrative(shapResult, index);
console.log("Narrative:", narrative);

// Then pass shapResult to CompImpactVisualizer