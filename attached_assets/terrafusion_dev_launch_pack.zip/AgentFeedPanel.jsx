import React, { useEffect, useState } from 'react';

function AgentFeedPanel({ onHighlight }) {
  const [events, setEvents] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [query, setQuery] = useState("");
  const [agentFilter, setAgentFilter] = useState("All");

  useEffect(() => {
    fetch("/agent_mesh_simulated_feed.json")
      .then(res => res.json())
      .then(data => {
        const sorted = data.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        setEvents(sorted);
        setFiltered(sorted);
      });
  }, []);

  useEffect(() => {
    let result = [...events];
    if (agentFilter !== "All") {
      result = result.filter(e => e.agent === agentFilter);
    }
    if (query.length > 0) {
      result = result.filter(e =>
        JSON.stringify(e.data).toLowerCase().includes(query.toLowerCase())
      );
    }
    setFiltered(result);
  }, [query, agentFilter, events]);

  const commentary = {
    VisionAgent: "Analyzed photo → Condition score",
    ValuationAgent: "SHAP-driven value adjustment",
    CompsAgent: "Suggested comps with high similarity",
    ForecastAgent: "Projected income forecast",
    LedgerAgent: "Logged events to audit trail"
  };

  const agentColors = {
    VisionAgent: "#ff006e",
    ValuationAgent: "#06d6a0",
    CompsAgent: "#ffd166",
    ForecastAgent: "#118ab2",
    LedgerAgent: "#8338ec"
  };

  function handleInvestigation(event) {
    if (onHighlight && typeof onHighlight === 'function') {
      onHighlight(event);
    }
  }

  return (
    <div style={{ padding: "1rem", backgroundColor: "#121212", color: "#e0e0e0", minHeight: "100vh" }}>
      <h2 style={{ color: "#00f5d4" }}>Agent Intelligence Feed</h2>
      <div style={{ marginBottom: "1rem" }}>
        <label style={{ marginRight: "1rem" }}>Filter by Agent:</label>
        <select value={agentFilter} onChange={(e) => setAgentFilter(e.target.value)}>
          <option>All</option>
          {Object.keys(commentary).map(agent => <option key={agent}>{agent}</option>)}
        </select>
        <input
          style={{ marginLeft: "1rem", padding: "0.2rem 0.5rem" }}
          type="text"
          placeholder="Search data..."
          value={query}
          onChange={e => setQuery(e.target.value)}
        />
      </div>
      {filtered.map((event, idx) => (
        <div key={idx} style={{
          marginBottom: "1rem",
          padding: "1rem",
          borderLeft: `5px solid ${agentColors[event.agent] || '#00f5d4'}`,
          backgroundColor: "#1f1f1f",
          borderRadius: "6px",
          cursor: "pointer"
        }} onClick={() => handleInvestigation(event)}>
          <strong>{event.agent}</strong> → <em>{event.type}</em><br />
          <small>{new Date(event.timestamp).toLocaleString()}</small>
          <pre style={{
            background: "#2c2c2c",
            padding: "0.5rem",
            borderRadius: "4px",
            color: "#c2f7ff"
          }}>{JSON.stringify(event.data, null, 2)}</pre>
          <div style={{
            fontStyle: "italic",
            fontSize: "0.9rem",
            color: "#94d2bd",
            marginTop: "0.5rem"
          }}>{commentary[event.agent] || "Agent action logged."}</div>
        </div>
      ))}
    </div>
  );
}

export default AgentFeedPanel;