import React, { useEffect, useRef } from 'react';

const fieldMap = {
  ValueUpdated: "urar-value",
  ConditionScored: "urar-condition",
  CompSuggested: "urar-comp-section",
  IncomeForecastGenerated: "urar-income",
  LogEntryCreated: "urar-log"
};

function URARForm({ highlighted }) {
  const refs = {
    "urar-value": useRef(),
    "urar-condition": useRef(),
    "urar-comp-section": useRef(),
    "urar-income": useRef(),
    "urar-log": useRef()
  };

  useEffect(() => {
    if (highlighted && fieldMap[highlighted.type]) {
      const id = fieldMap[highlighted.type];
      const element = refs[id].current;
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
        element.classList.add("highlighted");
        setTimeout(() => element.classList.remove("highlighted"), 2500);
      }
    }
  }, [highlighted]);

  return (
    <div style={{ backgroundColor: "#f5f5f5", padding: "2rem" }}>
      <h2>🧾 URAR Form</h2>
      <div id="urar-value" ref={refs["urar-value"]} className="urar-field">
        <label>Final Valuation:</label>
        <input type="text" defaultValue="$487,000" />
      </div>
      <div id="urar-condition" ref={refs["urar-condition"]} className="urar-field">
        <label>Property Condition:</label>
        <input type="text" defaultValue="C3" />
      </div>
      <div id="urar-comp-section" ref={refs["urar-comp-section"]} className="urar-field">
        <label>Comps:</label>
        <textarea defaultValue="Comp #1: 0.3mi, MLS9831, $475K, 95% match" rows="3" />
      </div>
      <div id="urar-income" ref={refs["urar-income"]} className="urar-field">
        <label>Income Forecast:</label>
        <input type="text" defaultValue="$18,600 / yr" />
      </div>
      <div id="urar-log" ref={refs["urar-log"]} className="urar-field">
        <label>Audit Log Reference:</label>
        <input type="text" defaultValue="Log #XREF202405" />
      </div>
      <style>{`
        .urar-field {
          margin-bottom: 1.5rem;
          padding: 1rem;
          background: #ffffff;
          border-left: 4px solid transparent;
          transition: border-color 0.4s ease;
        }
        .urar-field.highlighted {
          border-left-color: #06d6a0;
          box-shadow: 0 0 10px rgba(6, 214, 160, 0.6);
        }
        label {
          display: block;
          font-weight: bold;
          margin-bottom: 0.25rem;
        }
        input, textarea {
          width: 100%;
          padding: 0.5rem;
          border: 1px solid #ccc;
          border-radius: 4px;
        }
      `}</style>
    </div>
  );
}

export default URARForm;