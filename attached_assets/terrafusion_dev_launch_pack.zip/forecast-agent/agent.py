from event_emitter import emit_event

class ForecastAgent:
    def generate_forecast(self, parcel_id, horizon=12):
        forecast_data = {
            "parcel_id": parcel_id,
            "horizon_months": horizon,
            "predicted_income": 18250.00,
            "confidence": 89.7
        }
        emit_event("ForecastAgent", "IncomeForecastGenerated", forecast_data)