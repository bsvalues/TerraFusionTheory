#!/bin/bash
echo "Running ForecastAgent CI checks..."
python -m py_compile agent.py