from fastapi import FastAPI
from agent import ForecastAgent

app = FastAPI()
agent = ForecastAgent()

@app.get("/forecast/{parcel_id}")
def get_forecast(parcel_id: str, months: int = 12):
    agent.generate_forecast(parcel_id, months)
    return {"status": "Forecast emitted", "parcel_id": parcel_id}