# Setup Instructions

## Prerequisites
- Docker
- Python 3.10+
- Terraform
- Node.js (for UI modules)
- GitHub CLI

## Steps
1. Clone the repository
2. Create `.env` using `.env.example`
3. Run `docker-compose up` to bootstrap services
4. Apply infrastructure with Terraform
5. Trigger GitHub Actions for first build