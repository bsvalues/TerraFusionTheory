# TerraFusion DevKit

Welcome to the TerraFusion DevKit. This kit equips engineers to deploy, integrate, and extend the TerraFusion ecosystem.

## Contents
- `docs/`: Developer onboarding and component architecture
- `infrastructure/`: Terraform templates, Dockerfiles, Helm charts
- `pipelines/`: GitHub Actions for CI/CD
- `components/`: Base AI agent templates and microservice stubs

## Getting Started
1. Clone the repo
2. Follow `docs/01_SETUP.md`
3. Deploy infrastructure using `terraform apply`
4. Run CI/CD via GitHub or local pipelines

## Primary Services
- ForecastAgent
- CompsAgent
- LedgerAgent
- ValuationAgent