# TerraFusion DevKit + Audit Dashboard

This version includes a full cognitive audit dashboard:
- `AuditTab.jsx`: Displays override + retrain events
- `RetrainStatusWidget.jsx`: Shows latest retrain reason & model
- `public/retrain_timeline_plot.png`: Visual SHAP-based model timeline
- `public/ledger_agent_log.csv`: Logged AI actions for audit

Route `/audit` should be mounted in your app.