import React, { useEffect, useState } from 'react';

export default function AuditTab() {
  const [ledger, setLedger] = useState([]);
  const [retrainLog, setRetrainLog] = useState([]);

  useEffect(() => {
    fetch('/ledger_agent_log.csv')
      .then(res => res.text())
      .then(text => {
        const lines = text.trim().split('\n');
        const headers = lines[0].split(',');
        const rows = lines.slice(1).map(line => {
          const values = line.split(',');
          return Object.fromEntries(headers.map((h, i) => [h, values[i]]));
        });
        setLedger(rows.filter(row => row.event_type === 'override'));
        setRetrainLog(rows.filter(row => row.event_type === 'retrain'));
      });
  }, []);

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h2>Audit Log</h2>

      <section style={{ marginBottom: '2rem' }}>
        <h3>Override Events</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>User</th>
              <th>Field</th>
              <th>Old → New</th>
              <th>Justification</th>
              <th>Model</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {ledger.map((row, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #ccc' }}>
                <td>{row.user}</td>
                <td>{row.field}</td>
                <td>{row.old_value} → {row.new_value}</td>
                <td>{row.justification}</td>
                <td>{row.model_version}</td>
                <td>{new Date(row.timestamp).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ marginBottom: '2rem' }}>
        <h3>Retrain Events</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>Reason</th>
              <th>Old → New Model</th>
              <th>Triggered By</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {retrainLog.map((row, i) => (
              <tr key={i} style={{ borderBottom: '1px solid #ccc' }}>
                <td>{row.justification}</td>
                <td>{row.old_value} → {row.new_value}</td>
                <td>{row.user}</td>
                <td>{new Date(row.timestamp).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <a
        href="/retrain_timeline_plot.png"
        target="_blank"
        rel="noopener noreferrer"
        style={{
          display: 'inline-block',
          marginTop: '12px',
          padding: '10px 16px',
          backgroundColor: '#333',
          color: '#fff',
          textDecoration: 'none',
          borderRadius: '4px'
        }}
      >
        View Timeline Chart
      </a>
    </div>
  );
}