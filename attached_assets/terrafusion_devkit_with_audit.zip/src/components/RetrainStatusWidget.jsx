import React, { useEffect, useState } from 'react';

export default function RetrainStatusWidget() {
  const [log, setLog] = useState(null);

  useEffect(() => {
    fetch('/ledger_agent_log.csv')
      .then(res => res.text())
      .then(text => {
        const lines = text.trim().split('\n');
        const headers = lines[0].split(',');
        const rows = lines.slice(1).map(line => {
          const values = line.split(',');
          return Object.fromEntries(headers.map((h, i) => [h, values[i]]));
        });
        const latestRetrain = rows.reverse().find(row => row.event_type === 'retrain');
        setLog(latestRetrain);
      });
  }, []);

  if (!log) return <div>Loading retrain status...</div>;

  return (
    <div style={{
      background: '#1e1e2f',
      color: '#fff',
      padding: '16px',
      borderRadius: '8px',
      width: '100%',
      maxWidth: '500px',
      margin: 'auto'
    }}>
      <h3 style={{ marginBottom: '8px' }}>Latest Retrain Summary</h3>
      <p><strong>Model:</strong> {log.old_value} → {log.new_value}</p>
      <p><strong>Reason:</strong> {log.justification}</p>
      <p><strong>Triggered By:</strong> {log.user}</p>
      <p><strong>Time:</strong> {new Date(log.timestamp).toLocaleString()}</p>
      <a
        href="/retrain_timeline_plot.png"
        target="_blank"
        rel="noopener noreferrer"
        style={{
          display: 'inline-block',
          marginTop: '12px',
          padding: '8px 12px',
          backgroundColor: '#00bfa5',
          color: '#fff',
          textDecoration: 'none',
          borderRadius: '4px'
        }}
      >
        View Timeline Chart
      </a>
    </div>
  );
}