import React from 'react';
import './styles/terrafusion-theme.css';
import AgentFeedPanel from './AgentFeedPanel';
import URARForm from './URARForm';

export default function TerraFusionUXLayout() {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '2fr 1fr',
      gridTemplateRows: 'auto 1fr',
      gap: '16px',
      padding: '2rem',
      background: 'var(--tf-bg)',
      color: 'var(--tf-text)',
      height: '100vh'
    }}>
      <header style={{ gridColumn: '1 / span 2', paddingBottom: '1rem' }}>
        <h1 style={{ margin: 0, color: 'var(--tf-accent)' }}>TerraFusion Valuation Co-Pilot</h1>
      </header>

      <main style={{ overflowY: 'auto' }}>
        <URARForm />
      </main>

      <aside style={{ borderLeft: '1px solid var(--tf-border)', paddingLeft: '1rem', overflowY: 'auto' }}>
        <AgentFeedPanel />
      </aside>
    </div>
  );
}